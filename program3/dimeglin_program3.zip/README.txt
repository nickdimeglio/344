Nicholas DiMeglio
CS344 Program 3
2021-11-04 11:30PM EST 

Instructions for compilation:

	1. Unzip dimeglin_program3.zip in a directory of your choice
	2. From your terminal, inside the chosen directory, enter the command "make" 
	3. This directory now contains an executable file named smallsh
	4. Run the file using "./smallsh"
