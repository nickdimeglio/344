#ifndef SMALLSH_SIGNALS_H
#define SMALLSH_SIGNALS_H

void ignoreSIGINT();
void ignoreSIGTSTP();
void handleForegroundOnly();
#endif
