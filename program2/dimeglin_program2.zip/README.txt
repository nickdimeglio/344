Nicholas DiMeglio
CS344 Program 2
2021-10-18 8:47PM EST

Instructions for compilation:

	1. Unzip dimeglin_program2.zip in a directory of your choice
	2. Inside the new directory dimeglin_program2, enter the following bash command: "gcc -std=gnu99 -g -Wall -o movies_by_year movies_by_year.c"
	3. This directory now contains an executable file named movies_by_year
	4. Run the file using "./movies_by_year" 
