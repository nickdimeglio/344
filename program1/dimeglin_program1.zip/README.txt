Nicholas DiMeglio
CS344 Program 1
2021-10-11 9:48PM EST

Instructions for compilation:

	1. Unzip dimeglin_program1.zip in a directory of your choice
	2. In the same directory, enter the following bash command: "gcc -std=gnu99 -g -Wall -o movies movies.c"
	3. This directory now contains an executable file named movies
	4. Run the file using "./ movies filename" where filename is your csv filename
